from .visualize import visualize_collection
# here so it's a package